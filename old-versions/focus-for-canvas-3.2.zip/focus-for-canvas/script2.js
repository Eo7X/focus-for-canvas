function runInPage(code){
	chrome.tabs.getSelected(null, function(tab){
		chrome.tabs.executeScript(tab.id, {
			code: code
		}, function(response){
		});
	});
}


function removeInClass(class_name, from, to){
	runInPage('var elements = document.getElementsByClassName("' + class_name + '"); for (var i = 0; i < elements.length; i++) {var content = elements[i].innerHTML; var newcontent = content.replace(' + from + ', "' + to + '"); elements[i].innerHTML = newcontent;}');
}

chrome.tabs.onUpdated.addListener( function (tabid, changeinfo, tab) {
	if(changeinfo.status == 'complete'){
		removeInClass('tooltip', /5px/gi, "0px");
		removeInClass('final_grade', /5px/gi, "0px");
	}
});