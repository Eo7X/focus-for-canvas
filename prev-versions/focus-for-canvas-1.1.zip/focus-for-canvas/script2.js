chrome.tabs.getSelected(null, function(tab){
	chrome.tabs.executeScript(tab.id, {
		code: 'var elements = document.getElementsByClassName("tooltip"); for (var i = 0; i < elements.length; i++) {var content = elements[i].innerHTML; var newcontent = content.replace(/5px/gi, "0px"); elements[i].innerHTML = newcontent;}'
	}, function(response){

	});
});

//best id: tooltip

//var content = elements[i].innerHTML; var newcontent = content.replace(/5px/gi, "0px"); elements[i].innerHTML = newcontent;